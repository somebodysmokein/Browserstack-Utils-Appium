package com.browserstack.utils;

import com.automation.mobile.TestRunner;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class AsyncTask {


    private static Logger logger = LogManager.getLogger(AsyncTask.class);
    public static CompletableFuture pollForCompletion() {
        ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
        CompletableFuture<String> completionFuture = new CompletableFuture<>();
        AtomicInteger retry= new AtomicInteger();

            final ScheduledFuture<Void> checkFuture = (ScheduledFuture<Void>) executor.scheduleAtFixedRate(() -> {



                logger.info("Retry count =>"+retry.get());
                System.out.println("Retry count =>"+retry.get());
                try {
                    if (DownloadNetworkLogs.isDataReady() || retry.getAndIncrement() >3) {
                        completionFuture.complete("Complete");
                    }
                } catch (UnirestException e) {
                    e.printStackTrace();
                }

            }, 0, 10, TimeUnit.SECONDS);



            completionFuture.whenComplete((result, thrown) -> {
                checkFuture.cancel(true);
            });

        return completionFuture;
    }


}



