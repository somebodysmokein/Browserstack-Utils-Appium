package com.browserstack.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;

public class NetworkToggle {

    private Logger logger= LogManager.getLogger(NetworkToggle.class);
    public String baseUrl="https://api-cloud.browserstack.com/app-automate/sessions/<sessionid>/update_network.json";
    public ManagedAppiumDriver appiumDriver;

    public NetworkToggle(ManagedAppiumDriver appiumDriver)
    {
        this.appiumDriver=appiumDriver;
    }

    public void setOfflineMode() throws Exception {
        String url=this.baseUrl.replaceAll("<sessionid>",this.appiumDriver.getWebDriver().getSessionId().toString());
        HashMap<String,String> networkProfle=new HashMap<>();
        networkProfle.put("networkProfile","no-network");
        int retrycount=0;
        while(true) {
            try {
                retrycount++;
                boolean result = setNetworkProfile(networkProfle, url);
                if (result) {
                    logger.info("Device has been put into offline mode");
                } else {
                    logger.error("Not able to set Offline mode");
                    //throw new Exception("Not able to set Offline mode");
                }
                break;
            } catch (Exception e) {
                e.printStackTrace();
                logger.error(e.getMessage());

                if(retrycount==3)
                {
                    throw e;
                }else
                {
                    logger.error("Retrying to set the network profile");
                }

            }
        }
        //this.appiumDriver.getWebDriver()
    }

    public void setAirplaneMode() throws Exception {
        String url=this.baseUrl.replaceAll("<sessionid>",this.appiumDriver.getWebDriver().getSessionId().toString());
        HashMap<String,String> networkProfle=new HashMap<>();
        networkProfle.put("networkProfile","airplane-mode");
        int retrycount=0;
        while(true) {
            try {
                boolean result = setNetworkProfile(networkProfle, url);
                if (result) {
                    logger.info("Device has been put into airplane mode");
                    break;
                } else {
                    logger.error("Not able to set back to airplane mode");
                    //throw new Exception("Not able to set airplane mode");
                }

            } catch (Exception e) {
                e.printStackTrace();
                logger.error(e.getMessage());
                if (retrycount == 3) {
                    throw e;
                }else
                {
                    logger.error("Retrying to set the network profile");
                }
            }
        }
        }

    public void setDefaultMode() throws Exception {
        String url=this.baseUrl.replaceAll("<sessionid>",this.appiumDriver.getWebDriver().getSessionId().toString());
        HashMap<String,String> networkProfle=new HashMap<>();
        networkProfle.put("networkProfile","reset");
        boolean result=setNetworkProfile(networkProfle,url);
        if(result)
        {
            logger.info("Device has been put back to default mode");
        }else
        {
            logger.error("Not able to set back to default mode");
            throw new Exception("Not able to set back to default mode");
        }
    }

    public boolean setNetworkProfile(HashMap<String,String> networkProfile,String url) throws
            JsonProcessingException, UnirestException {
        HashMap<String,String> map=getCredentials();
        String json = new ObjectMapper().writeValueAsString(networkProfile);
        HttpResponse<JsonNode> jsonResponse=Unirest.put(url).basicAuth(map.get("userName"),map.get("passWord"))
                .header("Content-Type","application/json")
                .body(json).asJson();
        if(jsonResponse.getStatus() == 200)
        {
            return true;
        }else
        {
            return false;
        }

    }

    private HashMap<String,String> getCredentials()
    {
        HashMap<String,String> cred=new HashMap<>();
        Platform platform=this.appiumDriver.getPlatform();
        String tmpUser=platform.getCloudBrowserStackServer().split("//")[1];
        logger.info("tmpUser => "+tmpUser);
        String tmpUserArr[]=tmpUser.split("@");
        if(logger.isDebugEnabled()) {
            logger.debug("userName[0] =>" + tmpUserArr[0] + "userName[1] => " + tmpUserArr[1]);
        }
        String userName=tmpUserArr[0].split(":")[0];
        String passWord=tmpUserArr[0].split(":")[1];
        cred.put("userName",userName);
        cred.put("passWord",passWord);
        if(logger.isDebugEnabled()) {
            logger.debug("userName => " + userName + "; passWord => " + passWord);
        }
        return cred;
    }


}
