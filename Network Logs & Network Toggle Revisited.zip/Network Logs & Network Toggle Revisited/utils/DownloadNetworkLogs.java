package com.browserstack.utils;

import com.browserstack.DAO.NetworkLogs;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class DownloadNetworkLogs {

    private Logger logger= LogManager.getLogger(DownloadNetworkLogs.class);
    public String baseUrl="https://api-cloud.browserstack.com/app-automate/builds/<buildid>/sessions/<sessionid>/networklogs";

    public NetworkLogs getNetworkLogs(String buildId,String sessionId) throws
            Exception {

        String url=this.baseUrl.replaceAll("<sessionid>",sessionId);
        url=url.replaceAll("<buildid>",buildId);

        HttpResponse<JsonNode> jsonResponse= Unirest.get(url).basicAuth("venkateshr_0PiUN7","ADZqq5cND8dihy2RJAZD")
                .asJson();

        ObjectMapper mapper=new ObjectMapper();
        NetworkLogs ntwrklogs=mapper.readValue(jsonResponse.getBody().toString(),NetworkLogs.class);

        if(jsonResponse.getStatus() == 200)
        {
            File file = new File("output/report/networklogs-"+ sessionId+".json");
            LocalDateTime localTime = LocalDateTime.now(ZoneId.of("GMT+05:30"));
            File dir=new File("output/report/"+buildId+"-"+localTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            dir.mkdir();
            FileWriter writer=new FileWriter(new File(dir.getAbsolutePath()+File.separator+
                    "networklogs-"+ sessionId+".json"));
            writer.write(jsonResponse.getBody().toString());
            writer.close();
            return ntwrklogs;
        }else
        {
            throw new Exception("Not able to extract network logs");
        }

    }

    public static boolean isDataReady() throws UnirestException {
        NetworkLogTracker networkData= NetworkLogTracker.getInstance();
        boolean isDataReady=false;
        Iterator itr= networkData.getSessionDetails().entrySet().iterator();
        while(itr.hasNext())
        {

            Map.Entry<String,String> map=(Map.Entry<String,String>)itr.next();
            String baseUrl="https://api-cloud.browserstack.com/app-automate/builds/"+map.getValue()+
                    "/sessions/"+map.getKey()+"/networklogs";
            int retry=0;
            while(true) {

                retry++;
                try {
                    HttpResponse<JsonNode> jsonResponse = Unirest.get(baseUrl).basicAuth("venkateshr_0PiUN7", "ADZqq5cND8dihy2RJAZD")
                            .asJson();

                    if (jsonResponse.getStatus() == 200) {
                        if (jsonResponse.getBody() != null) {
                            isDataReady = true;
                            break;
                        }
                    }
                } catch (UnirestException e) {
                    System.out.println("Retry "+retry+" for session =>"+ map.getKey());
                    if(retry==3) {
                        System.out.println("Max Retry "+retry+" for session =>"+ map.getKey());
                        e.printStackTrace();
                        throw e;
                    }
                }
            }

        }
        return isDataReady;
    }

}

