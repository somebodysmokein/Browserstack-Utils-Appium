package com.browserstack.utils;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Platform {

    private String device;
    @JsonProperty("deviceName")
    private String devicename;
    private String os_version;
    private String platformname;
    private String devicetype;
    private String realdevice;
    private String activityName;
    private String packageName;
    private String bundleId;
    private String appNameBuild;
    private String user;
    private String password;
    private String apiKey;
    @JsonProperty("CloudServer")
    private String cloudServer;
    private String token;
    private String userName;
    private String accessKey;
    @JsonProperty("CloudBrowserStackServer")
    private String cloudBrowserStackServer;
    private String env;
    @JsonProperty("STATE")
    private String state;
    @JsonProperty("REGISTERUSER")
    private String registeruser;

    @JsonProperty("networkLogs")
    private String networklogs;

    public String getNetworklogs() {
        return networklogs;
    }

    public void setNetworklogs(String networklogs) {
        this.networklogs = networklogs;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getRegisteruser() {
        return registeruser;
    }

    public void setRegisteruser(String registeruser) {
        this.registeruser = registeruser;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getDevicename() {
        return devicename;
    }

    public void setDevicename(String devicename) {
        this.devicename = devicename;
    }

    public String getOs_version() {
        return os_version;
    }

    public void setOs_version(String os_version) {
        this.os_version = os_version;
    }

    public String getPlatformname() {
        return platformname;
    }

    public void setPlatformname(String platformname) {
        this.platformname = platformname;
    }

    public String getDevicetype() {
        return devicetype;
    }

    public void setDevicetype(String devicetype) {
        this.devicetype = devicetype;
    }

    public String getRealdevice() {
        return realdevice;
    }

    public void setRealdevice(String realdevice) {
        this.realdevice = realdevice;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public String getAppNameBuild() {
        return appNameBuild;
    }

    public void setAppNameBuild(String appNameBuild) {
        this.appNameBuild = appNameBuild;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getCloudServer() {
        return cloudServer;
    }

    public void setCloudServer(String cloudServer) {
        cloudServer = cloudServer;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getCloudBrowserStackServer() {
        return cloudBrowserStackServer;
    }
    public void setCloudBrowserStackServer(String cloudBrowserStackServer) {
        this.cloudBrowserStackServer = cloudBrowserStackServer;
    }
}
