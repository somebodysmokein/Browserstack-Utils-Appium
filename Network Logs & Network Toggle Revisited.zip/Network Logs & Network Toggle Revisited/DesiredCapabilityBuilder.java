package com.automation.mobile.appium;

import com.automation.mobile.entities.*;
import com.automation.mobile.util.BrowserStackUtils;
import com.automation.mobile.util.KobitonIntegrate;
import com.mashape.unirest.http.exceptions.UnirestException;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.IOException;


public class DesiredCapabilityBuilder {

    private static Logger logger = LogManager.getLogger(DesiredCapabilityBuilder.class);
    private static ThreadLocal<DesiredCapabilities> desiredCapabilitiesThreadLocal = new ThreadLocal<>();
    static int versionId;
    public static JSONObject appUrlObj;

    public static DesiredCapabilities getDesiredCapability() {
        return desiredCapabilitiesThreadLocal.get();
    }

    public static int getVersionId() {
        return versionId;
    }

    private static String getAppPath(AppiumDevice appiumDevice) throws IOException {

        String platform = appiumDevice.getConfigureData(MobileConfType.PLATFORM_NAME);
        String environment = appiumDevice.getConfigureData(ConfigType.APP_ENVIRONMENT);
        String deviceType = appiumDevice.getConfigureData(MobileConfType.DEVICE_TYPE);
        String iosdevice = appiumDevice.getConfigureData(MobileConfType.IOS_DEVICE);
        String appName = appiumDevice.getConfigureData(AppConfType.APPNAME_BUILD);
        String appPath = FileLocations.MOBILE_APP_LOCATION + platform + "/" + environment + "/" + appName;


        if ((deviceType.equalsIgnoreCase("cloudKobiton")) || (deviceType.equalsIgnoreCase("cloudBrowserStack"))) {
            logger.info("Cloud device");

            if (platform.equalsIgnoreCase("ios")) {

                appPath += ".ipa";

            } else {

                appPath += ".apk";
            }

        } else {
            if ((platform.equalsIgnoreCase("ios")) && (iosdevice.equalsIgnoreCase("true"))) {

                appPath += ".ipa";
            } else if (platform.equalsIgnoreCase("ios")) {

                appPath += ".app";

            } else {

                appPath += ".apk";
            }
        }
        return appPath;
    }

    private static String getAppName(AppiumDevice appiumDevice) {

        String deviceType = appiumDevice.getConfigureData(MobileConfType.DEVICE_TYPE);
        String platform = appiumDevice.getConfigureData(MobileConfType.PLATFORM_NAME);
        String appName = appiumDevice.getConfigureData(AppConfType.APPNAME_BUILD);
        String iosdevice = appiumDevice.getConfigureData(MobileConfType.IOS_DEVICE);

        if ((deviceType.equalsIgnoreCase("cloudKobiton")) || (deviceType.equalsIgnoreCase("cloudBrowserStack"))) {

            if (platform.equalsIgnoreCase("ios")) {

                appName += ".ipa";

            } else {

                appName += ".apk";
            }
        } else {
            if ((platform.equalsIgnoreCase("ios")) && (iosdevice.equalsIgnoreCase("true"))) {

                appName += ".ipa";
            } else if (platform.equalsIgnoreCase("ios")) {

                appName += ".app";

            } else {

                appName += ".apk";
            }
        }
        return appName;
    }

    public static void buildDesiredCapability(AppiumDevice appiumDevice) throws IOException, UnirestException {
        AppiumDevice ad = appiumDevice;
        String platform = ad.getConfigureData(MobileConfType.PLATFORM_NAME);
        String env = ad.getConfigureData(ConfigType.APP_ENVIRONMENT);
        String deviceType = ad.getConfigureData(MobileConfType.DEVICE_TYPE);
        String realdevice = ad.getConfigureData(MobileConfType.REAL_DEVICE);
        String appPath = getAppPath(ad);
        String appName = getAppName(ad);

        DesiredCapabilities dc = new DesiredCapabilities();

        logger.info("setting general capabilities");
        if (deviceType.equalsIgnoreCase("cloudBrowserStack")) {
            dc.setCapability(MobileCapabilityType.DEVICE_NAME, ad.getConfigureData(MobileConfType.DEVICE));
            dc.setCapability("os_version", ad.getConfigureData(MobileConfType.OS_VERSION));
        } else {
            dc.setCapability(MobileCapabilityType.DEVICE_NAME, ad.getConfigureData(MobileConfType.DEVICE_NAME));
            dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, ad.getConfigureData(MobileConfType.PLATFORM_VERSION));
        }
        dc.setCapability(MobileCapabilityType.PLATFORM_NAME, ad.getConfigureData(MobileConfType.PLATFORM_NAME));
        dc.setCapability("enableAppiumBehavior", true);
        dc.setCapability("env", env);
        // clears cache and settings reinstall
        dc.setCapability(MobileCapabilityType.FULL_RESET, true);
        dc.setCapability(MobileCapabilityType.NO_RESET, false);

        if (platform.equalsIgnoreCase("android")) {
            logger.info(" setting android capabilities");
            dc.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, ad.getConfigureData(AppConfType.PACKAGE_NAME));
            dc.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, ad.getConfigureData(AppConfType.ACTIVITY_NAME));
            if (ad.getConfigureData(MobileConfType.AVD) != null) {
                dc.setCapability(AndroidMobileCapabilityType.AVD, ad.getConfigureData(MobileConfType.AVD));
            }
        } else if ((platform.equalsIgnoreCase("ios")) && ((deviceType.equalsIgnoreCase("local") || (realdevice.equalsIgnoreCase("true"))))) {
            dc.setCapability(IOSMobileCapabilityType.BUNDLE_ID, ad.getConfigureData(AppConfType.BUNDLE_ID));
        }
        //ios sign capability
        if (platform.equalsIgnoreCase("ios") && ((deviceType.equalsIgnoreCase("local")))) {
            logger.info(" setting ios capabilities");
            //dc.setCapability(IOSMobileCapabilityType.XCODE_ORG_ID, ad.getConfigureData(MobileConfType.IOS_XCODE_ORGID));
            //dc.setCapability(IOSMobileCapabilityType.XCODE_SIGNING_ID,ad.getConfigureData(MobileConfType.IOS_XCODE_SIGNINGID));
            dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
            //dc.setCapability("iOSResign", true);
            dc.setCapability("simpleIsVisibleCheck", true);
            dc.setCapability("wdaLocalPort", wdaLocalPort());
            dc.setCapability("webkitDebugProxyPort", webkitDebugProxyPort());

        }
        if (deviceType.equalsIgnoreCase("cloudKobiton")) {
            logger.info(" setting cloud capabilities");
            String user = ad.getConfigureData(AppConfType.CLOUD_USER);
            String password = ad.getConfigureData(AppConfType.CLOUD_PASSWORD);
            dc.setCapability("resignApp", false);
            dc.setCapability("sessionName", "Automation test session");
            dc.setCapability("sessionDescription", "");
            dc.setCapability("deviceOrientation", "portrait");
            dc.setCapability("captureScreenshots", true);
            dc.setCapability("user", user);
            dc.setCapability("password", password);
            dc.setCapability("securityToken", appiumDevice.getCouldToken());
            dc.setCapability("groupId", 2844); //Group : Amway
            dc.setCapability("deviceGroup", "KOBITON");
            versionId = KobitonIntegrate.uploadAppKobiton(appPath, appName);
            dc.setCapability("app", "kobiton-store:v" + versionId + "");
        }
        else if (deviceType.equalsIgnoreCase("cloudBrowserStack")) {
            if(platform.equalsIgnoreCase("ios")) {
                logger.info("setting resign capabilities to false for IOS platform");
                dc.setCapability("browserstack.resignApp", "false");
            }
            /*if(appUrlObj==null) {
                appUrlObj = new JSONObject(BrowserStackUtils.uploadUsingUniRest(appPath));
            }*/
            /*synchronized (AppInfo.getInstance()){
                if (AppInfo.getInstance().appUrl.get(platform) == null) {
                    appUrlObj = new JSONObject(BrowserStackUtils.uploadUsingUniRest(appPath));
                    AppInfo.getInstance().appUrl.put(platform, appUrlObj.getString("app_url"));
                }
            }*/

            dc.setCapability("project", "Creators App");
            dc.setCapability("build", "BrowserStackAppTest");
            dc.setCapability("name", RandomStringUtils.randomNumeric(4));
            if(ad.getNetworkLogInd().equalsIgnoreCase("true")) {
                dc.setCapability("browserstack.networkLogs", "true");
            }
            //logger.info("uploaded app url :  " + appUrlObj.getString("app_url"));
            //dc.setCapability("app", appUrlObj.getString("app_url"));
            dc.setCapability("app","bs://987f6a0c3b794bd934709a869faff1195855c119");
        } else {
            //local device install app
            dc.setCapability(MobileCapabilityType.UDID, ad.getConfigureData(MobileConfType.UDID));
            dc.setCapability(MobileCapabilityType.APPLICATION_NAME, ad.getConfigureData(MobileConfType.APPLICATION_NAME));
            dc.setCapability(MobileCapabilityType.APP, appPath);
        }
        dc.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 240);
        desiredCapabilitiesThreadLocal.set(dc);
        logger.info(desiredCapabilitiesThreadLocal.get().toString());
    }

    /**
     * Generating a unique wdalocalport using randomStringUtils class
     *
     * @return : 4 digit wda port 8100
     */
    public static int wdaLocalPort() {
        String wdaLocal = RandomStringUtils.randomNumeric(4);
        logger.info("wda local  port is " + wdaLocal);
        return Integer.parseInt(wdaLocal);
    }

    /**
     * Generating a unique wdalocalport using randomStringUtils class
     *
     * @return : 4 digit webkitDebugProxyPort ex: 1104
     */
    public static int webkitDebugProxyPort() {
        String webkitDebugProxy = RandomStringUtils.randomNumeric(4);
        logger.info("webKit debug proxy is " + webkitDebugProxy);
        return Integer.parseInt(webkitDebugProxy);
    }
}
