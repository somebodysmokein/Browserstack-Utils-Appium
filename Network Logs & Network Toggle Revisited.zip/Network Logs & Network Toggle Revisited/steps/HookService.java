package com.automation.steps;

import com.automation.helpers.AppActions;
import com.automation.helpers.DeviceHelper;
import com.automation.helpers.PageActions;
import com.automation.mobile.TestRunner;
import com.automation.mobile.appium.AppiumDevice;
import com.automation.mobile.appium.AppiumDeviceManager;
import com.automation.mobile.appium.AppiumDriverManager;
import com.automation.mobile.appium.DesiredCapabilityBuilder;
import com.automation.mobile.entities.MobileConfType;
import com.automation.mobile.listener.VideoManager;

import com.automation.mobile.manager.ConfigFileManager;
import com.automation.mobile.util.CommonUtil;
import com.automation.mobile.util.GlobalVar;
import com.browserstack.utils.AccessNetworkLogs;
import com.browserstack.utils.NetworkLogTracker;
import com.mashape.unirest.http.exceptions.UnirestException;
import io.appium.java_client.AppiumDriver;
;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.DesiredCapabilities;

import javax.swing.text.StyledEditorKit;
import java.io.IOException;
import java.net.URL;
import java.util.Map;
import java.util.Properties;

import static com.automation.mobile.appium.AppiumDriverManager.getDriver;

public class HookService {

    //AppiumDriver appiumDriver;
    //AppiumDevice appiumDevice = AppiumDeviceManager.getDevice();
    private static Logger logger = LogManager.getLogger(HookService.class);

    //Page Objects
    protected static Properties prop;
    protected ConfigFileManager configFileManager;

    @Before
    public void before(Scenario scenario) throws IOException, InterruptedException, UnirestException {
        logger.info("**************hooks*********************" + Thread.currentThread().getId());
            /*synchronized (GlobalVar.DEVICE_LIST) {
            for (String mobile : GlobalVar.DEVICE_LIST.keySet()) {
                Map<String, String> tempMap = GlobalVar.DEVICE_LIST.get(mobile);
                logger.info(GlobalVar.DEVICE_LIST);

                //create appium device
                appiumDevice = new AppiumDevice(tempMap);
                AppiumDeviceManager.setDevice(appiumDevice);

                //create desired capability
                DesiredCapabilityBuilder.buildDesiredCapability(appiumDevice);
                logger.info(appiumDevice);
                logger.info(Thread.currentThread().getId());

                AppiumDevice device = AppiumDeviceManager.getDevice();
                String platForm = device.getConfigureData(MobileConfType.PLATFORM_NAME);
                String deviceType = device.getConfigureData(MobileConfType.DEVICE_TYPE);
                if (((platForm.equalsIgnoreCase("android")) || (platForm.equalsIgnoreCase("ios")))
                        && ((!deviceType.equalsIgnoreCase("cloudKobiton"))) && (!deviceType.equalsIgnoreCase("cloudBrowserStack"))) {
                    //create appium server
                    appiumDriver = new AppiumDriverManager().
                            initializeDriver(new URL(appiumDevice.getConfigureData(MobileConfType.APPIUM_SERVER)),
                                    DesiredCapabilityBuilder.getDesiredCapability());
                } else {
                    try {
                        appiumDriver = new AppiumDriver(new URL(appiumDevice.getConfigureData(MobileConfType.APPIUM_SERVER)),
                                DesiredCapabilityBuilder.getDesiredCapability());
                        logger.info("session ID :" + appiumDriver.getSessionId());
                        //Launches the app and (re)starts the session.
                        appiumDriver.launchApp();
                    } catch (Exception ex) {
                        logger.info(ex.getMessage());
                        appiumDriver = new AppiumDriver(new URL(appiumDevice.getConfigureData(MobileConfType.APPIUM_SERVER)),
                                DesiredCapabilityBuilder.getDesiredCapability());
                        logger.info("session ID :" + appiumDriver.getSessionId());
                        //Launches the app and (re)starts the session.
                        appiumDriver.launchApp();
                    }
                }
                AppiumDriverManager.setDriver(appiumDriver);
                AppiumDriverManager.addDriver(appiumDriver);
                //Initialization of classes
                //pageObjectInitialization();
                break;
            }
            }*/
        //Initialization of classes
        pageObjectInitialization();
    }
    @After
    public void afterStep(Scenario scenario) throws Exception {
        boolean ntwrkInd=false;

        try {
            ntwrkInd = Boolean.parseBoolean(TestRunner.getManagedWebDriver().getPlatform().getNetworklogs());
            logger.info("ntwrkInd for " + TestRunner.getManagedWebDriver()
                    .getWebDriver().getSessionId() + " is " + ntwrkInd);
        }catch(NullPointerException e)
        {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        if(ntwrkInd) {
            AccessNetworkLogs logs = new AccessNetworkLogs(TestRunner.getManagedWebDriver());
            NetworkLogTracker tracker = NetworkLogTracker.getInstance();
            tracker.setSession(logs.getBuildId(), TestRunner.getManagedWebDriver().getWebDriver().getSessionId().toString());
        }
        //logs.getNetworkLogs();

        for (String mobile : GlobalVar.DEVICE_LIST.keySet()) {
            Map<String, String> tempMap = GlobalVar.DEVICE_LIST.get(mobile);
            logger.info(GlobalVar.DEVICE_LIST);
            //create appium device
            AppiumDevice appiumDevice = new AppiumDevice(tempMap);
            AppiumDeviceManager.setDevice(appiumDevice);
            if (scenario.isFailed()) {
                String deviceName = AppiumDeviceManager.getDevice().getDeviceName();
                String platform = AppiumDeviceManager.getDevice().getPlatform();
                String dateTime = AppiumDriverManager.dateTime();
                logger.info("******Capturing screen shot  ************" + "_" + platform + "_" + deviceName + "_" + dateTime);
                scenario.attach(CommonUtil.captureScreenshot(getDriver()), "image/png", platform + "_" + deviceName + "_" + dateTime);
                //capturing failed scenario via video
                if ((!AppiumDeviceManager.getDevice().getDeviceType().equalsIgnoreCase("cloudBrowserStack")) && ((!AppiumDeviceManager.getDevice().getDeviceType().equalsIgnoreCase("cloudKobiton")))) {
                    new VideoManager().stopRecording(scenario.getName());
                }
            }
        }


    }
    /**
     * Initializing all the helper and properties classes
     *
     * @author Mohammed Haseeb
     */
    public void pageObjectInitialization() {
        //Initialization of objects


        configFileManager = new ConfigFileManager();
        prop = configFileManager.initProp();

    }

//    public String getFeatureName() {
//        String featurePath = ThreadLocalHelper.feature.get().getUri().getPath();
//        return FilenameUtils.removeExtension(featurePath.substring(featurePath.lastIndexOf("/") + 1));
//    }
}

